// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
    apiKey: "AIzaSyBbukCKWbERks_QexrFN0ly1ZS6G2fIxXE",
    authDomain: "the-marion-company.firebaseapp.com",
    databaseURL: "https://the-marion-company-default-rtdb.firebaseio.com",
    projectId: "the-marion-company",
    storageBucket: "the-marion-company.appspot.com",
    messagingSenderId: "685762909857",
    appId: "1:685762909857:web:c2d9e94e624e3067ef42e0",
    measurementId: "G-2TVPHWW2RG"
  };




// Initialize Firebase
firebase.initializeApp(firebaseConfig);
firebase.analytics();


