// Data Picker Initialization
$('.datepicker').pickadate();